module Compass
  # This file intentionall does nothing.
  # The compass build scripts put the release VERSION constant here.
end
