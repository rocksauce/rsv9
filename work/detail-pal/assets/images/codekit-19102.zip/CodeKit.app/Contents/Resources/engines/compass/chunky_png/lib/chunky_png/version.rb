module ChunkyPNG
  # The current version of ChunkyPNG.
  # Set it and commit the change this before running rake release.
  VERSION = "1.3.3"
end
